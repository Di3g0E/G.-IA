import Instance


class Algorithm:    # Esto es solo pa obligar a que quien lo herede deba de tener un execute.
    def execute(self, instance: Instance):
        pass
