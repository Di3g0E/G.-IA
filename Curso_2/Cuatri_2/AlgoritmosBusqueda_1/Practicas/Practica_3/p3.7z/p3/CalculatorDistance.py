from math import sqrt


class CalculatorDistance:   # Clase de utilidades.
    @staticmethod   # No hace falta instanciar el objeto pa usarlo, no hace falta constructor.
    def calculate_euclidean_distance_matrix(latitudes: list[int], longitudes: list[int]) -> list[list[int]]:
        distance_matrix: list[list[int]] = []
        x: int = 0
        for latitude1, longitude1 in latitudes, longitudes:
            distance_matrix.append([])
            y: int = 0
            for latitude2, longitude2 in latitudes, longitudes:
                distance_matrix[x].append(CalculatorDistance.calculate_euclidean_distance(latitude1, longitude1,
                                                                                          latitude2, longitude2))
                y += 1
            x += 1
        return distance_matrix

    @staticmethod
    def calculate_euclidean_distance(latitude_nodo_1: int, longitude_node_1: int, latitude_nodo_2: int,
                                     longitude_node_2: int) -> int:
        return int(sqrt(((latitude_nodo_2 - latitude_nodo_1)**2) + ((longitude_node_2 - longitude_node_1)**2)))
