import Instance
from Solution import Solution


class Constructive:
    def construct(self, instancia: Instance) -> Solution:  # random de la lista
        pass
