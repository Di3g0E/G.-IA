import Instance
from Solution import Solution
import random


class ConstructiveRANDOM:
    def construct(self, instancia: Instance) -> Solution:
        node_list = instancia.node_list
        random.shuffle(instancia.node_list)
        solution = Solution(instancia.node_list, 0, instancia)
        solution.evaluate()
        return solution
