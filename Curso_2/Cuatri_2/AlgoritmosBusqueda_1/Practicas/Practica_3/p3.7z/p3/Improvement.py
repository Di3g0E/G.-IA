from Solution import Solution


class Improvement:
    def improve(self, solution: Solution):
        pass
